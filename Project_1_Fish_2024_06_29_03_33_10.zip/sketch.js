/**
 * Project 1 - Interactive Fish Underwater
 * Name: Cali Yario
 * Completion date: 6/28/24
 *
 * Description:
 * This project creates an interactive underwater scene using P5.js. that includes a fish swimming and bubbles effects.
 * The fish moves horizontally based on the mouse position
 * bubbles are generated on mouse clicks. The scene is on a 600x400 pixel canvas with a
 * light gray background.
 *
 * User Interactions:
 * - Mouse movement.Controls the horizontal movement of the fish.
 * - Mouse click.Generates the bubbles at the location of the mouse.
 *
 * Sources:
 Course References:
 - P5.js Reference: https://p5js.org/reference/
 * - Chapters 3-8: Programming Fundamentals
 * - Lecture notes and class discussions
 * 
 * External Resources:
 * - The Coding Train (YouTube channel): Inspiration and learning for creative coding with P5.js
 */

// Global Variables
let fishX, fishY; // Position of the fish
let fishSize = 50; // Size of the fish
let fishSpeed = 2; // Speed of the fish
let bubbleX, bubbleY; // Position of bubbles
let bubbles = []; //  For bubble objects

function setup() {
  createCanvas(600, 400);
  fishX = width / 2; // Fish in middle
  fishY = height / 2; // Fish in middle vertically
  bubbleX = width / 2; // Bubbles at middle horizontally
  bubbleY = height; // Start bubbles at bottom vertically
}

function draw() {
  background(100, 200, 255); // Light blue (water color)

  // Draw bubbles
  for (let bubble of bubbles) {
    bubble.move();
    bubble.display();
  }

  // Draw fish
  drawFish(fishX, fishY, fishSize);

  // Move fish based on mouse
  fishX += (mouseX - fishX) * 0.1;
  fishY += (mouseY - fishY) * 0.1;

  // Limit fish on canvas
  fishX = constrain(fishX, 0, width);
  fishY = constrain(fishY, 0, height);

  if (mouseIsPressed) {
    if (frameCount % 20 === 0) {
      // bubbles every 20 frames
      bubbles.push(new Bubble(random(width), height));
    }
  }
}

function drawFish(x, y, size) {
  push();
  translate(x, y);
  // Body
  fill(255, 150, 0); // Orange
  ellipse(0, 0, size, size / 2);
  // Tail
  fill(255, 150, 0); // Orange
  triangle(-size / 2, 0, -size, -size / 3, -size, size / 3);
  // Eye
  fill(0); // Black
  ellipse(size / 4, 0, size / 10);
  pop();
}

// Bubble def
class Bubble {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.radius = random(5, 15);
    this.speed = random(1, 3);
  }

  move() {
    this.y -= this.speed; // Move bubble up
    if (this.y < 0) {
      this.y = height; // Reset
    }
  }

  display() {
    noStroke();
    fill(200, 240, 255); // Light blue
    ellipse(this.x, this.y, this.radius * 2);
  }
}
function mousePressed() {
  bubbles.push(new Bubble(random(width), height)); // Generate new bubble at random
}
